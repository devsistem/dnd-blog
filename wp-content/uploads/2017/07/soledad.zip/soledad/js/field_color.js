jQuery(document).ready(function ($) {
    $('input.popup-colorpicker').wpColorPicker({
    	palettes: ['#bf9f5a', '#f6653c', '#2ac4ea', '#ae81f9', '#FD544F', '#78cd6e']
    });
});
