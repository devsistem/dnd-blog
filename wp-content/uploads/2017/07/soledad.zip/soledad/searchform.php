<form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
		<input type="text" class="search-input" placeholder="<?php esc_html_e('Type and hit enter...', 'soledad'); ?>" name="s" id="s" />
	 </div>
</form>